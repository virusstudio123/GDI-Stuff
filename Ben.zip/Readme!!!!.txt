BEN.exe
Made in: C++
Malware Type: Trojan
Made By: Return My Pal
Damage rate: Destructive, guideness Run Administrator it Overwrite MBR, Does NOT Run Administrator it safe
Works Best In: Windows XP, Windows 7, Windows 8.1, Windows 10, Windows 11
